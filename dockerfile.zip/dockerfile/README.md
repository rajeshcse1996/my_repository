# Read Me

A walkthrough on setting up you secrets with AWS Key Management Service (KMS) can be found here https://aws.amazon.com/blogs/compute/managing-secrets-for-amazon-ecs-applications-using-parameter-store-and-iam-roles-for-tasks/Managing
